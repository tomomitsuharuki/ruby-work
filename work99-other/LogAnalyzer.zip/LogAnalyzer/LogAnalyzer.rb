#!/usr/bin/env ruby
# coding: utf-8
##------------------------------------------------------------------------------------------------
ENV['INLINEDIR'] = File.dirname(File.expand_path(__FILE__))  # for ocra
$stdout.sync = true
##------------------------------------------------------------------------------------------------
require "yaml"
require "pp"

##------------------------------------------------------------------------------------------------
PATTERN_FILE = 'analyze_pattern.yml'
BAR_SIZE = 50

ResultLine = Struct.new(:file, :lineno, :line)
ResultInfo = Struct.new(:pattern, :result_array)

##------------------------------------------------------------------------------------------------
def progress_bar(i, max = 100)
  i = max if i > max
  rest_size = 1 + 5 + 1      # space + progress_num + %
  bar_width = BAR_SIZE - rest_size # (width - 1) - rest_size
  percent = i * 100.0 / max
  bar_length = i * bar_width.to_f / max
  bar_str = ('#' * bar_length).ljust(bar_width)
  progress_num = '%3.1f' % percent
  print "\r[#{bar_str}] #{'%5s' % progress_num}% (#{i}/#{max})"
end

def gets_input
  print "Input log file => "
  return gets.chomp
end

def check_file(file_path)
  unless file_path && File.exist?(file_path)
    puts "file open error =>" + file_path
    exit
  end
end

def get_file
  file_name = ARGV[0].nil? ? gets_input : ARGV[0]
  check_file(file_name)
  puts "File is [#{file_name}]"
  return file_name
end

def get_output_file(input_file)
  return File.basename(input_file, File.extname(input_file)) + "_result" + File.extname(input_file)
end

def get_line_num(input_file)
  line_num = 0
  open(input_file) do |f|
    while f.gets
      print "." if f.lineno % 10000 == 0
    end
    print "\n"
    line_num = f.lineno
  end
  return line_num
end

def create_result_info(check_pattern)
  result_info = {}
  check_pattern.each do |key, value|
    resultInfo = ResultInfo.new(value, Array.new)
    result_info[key] = resultInfo
  end
  return result_info
end

def analyze(input_file, output_file, max_line, check_pattern, result_info)

  hit_count = 0
  open(input_file) do |f|

    f.each_line do |line|

      check_pattern.each do |key, value|
        check = line.include?(value)
        if check
          hit_count += 1
          result_line = ResultLine.new(input_file, f.lineno, line)
          result_info[key].result_array.push(result_line)
        end
      end
      progress_bar(f.lineno, max_line)

    end
  end
  print "\n"
  puts "Hit is #{hit_count}"
end

def show_check_pattern(check_pattern)
  puts "Check pattern"
  pp check_pattern
end

def show_result(result_info)
  puts "Result"
  # pp result_info
  result_info.each do |key, value|
    if value.result_array.empty?
      puts "<<< #{key} : No Hit. >>>"
    else
      puts "<<< #{key} : !!! #{value.result_array.size} Hit !!! >>>"
      # value.result_array.each do |result|
      #   puts "  Line[#{result.lineno}] => [#{result.line}]"
      # end
    end
  end
end

def save_result(output_file, result_info)
  open(output_file, 'w') do |file|
    result_info.each do |key, value|
      file.puts "<<< #{key} : #{value.pattern} >>>"
      if value.result_array.empty?
        file.puts "  No Hit."
      else
        file.puts "  !!! #{value.result_array.size} Hit !!!"
        value.result_array.each do |result|
          file.puts "  #{result.file}(L#{result.lineno}) => #{result.line}"
        end
      end
    end
  end
  puts "Write to #{output_file}"
end

##------------------------------------------------------------------------------------------------
# Input Output file
puts "============================================="
input_file = get_file()
output_file = get_output_file(input_file)
puts "Checke start"
max_line = get_line_num(input_file)
puts "Max [#{max_line}] lines"

# Check pattern
check_pattern = YAML.load_file(PATTERN_FILE)
# show_check_pattern(check_pattern)

# Analyze
puts "Analyze start"
result_info = create_result_info(check_pattern)
analyze(input_file, output_file, max_line, check_pattern, result_info)
show_result(result_info)
save_result(output_file, result_info)

##------------------------------------------------------------------------------------------------
puts "Return to End"
gets
puts "Finish"