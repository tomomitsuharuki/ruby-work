#!/usr/bin/env ruby
# -*- coding: utf-8-*-

require "net/http"
require 'uri'
require 'json'
require 'optparse'

##------------------------------------------------------------------------------------------------
IP_ADDR            = "43.31.105.177"
PORT               = 50100
SERVICE_GROUP_LIST = /avContent|appControl|audio|recording|system|cec|video|broadcast|contentSync/
SERVICE_GROUP_HELP = "avContent|appControl|audio|recording|system|cec|video|broadcast|contentSync"

##------------------------------------------------------------------------------------------------
option={}
OptionParser.new do |opt|
  opt.on('-s ServiceGroup', SERVICE_GROUP_LIST, SERVICE_GROUP_HELP)   {|v| option[:s] = v}
  opt.on('-f RequestFile',   'Request File')                          {|v| option[:f] = v}

  opt.parse!(ARGV)
end
p option
if option[:s].nil?
  puts "Service Group Empty"
  exit
end
##------------------------------------------------------------------------------------------------
def print_json(json)
  print JSON.pretty_generate(json) + "\n"
end

def check_file(file_path)
  unless file_path && File.exist?(file_path)
    puts "file open error =>" + file_path
    exit
  end
  return file_path
end

def get_respons_file(file_path)
  respons_file = File.basename(file_path, File.extname(file_path)) + "_respons" + File.extname(file_path)
  return respons_file
end

def load_json(file_path)
  request_body = open(file_path) do |io|
    JSON.load(io)
  end
  return request_body
end

def write_json(respons_file, respons_body)
  open(respons_file, 'w') do |file|
    file.print JSON.pretty_generate(respons_body)
  end
end

def request(service_group, request_body)
  print "=== request ===\n"
  print_json(request_body)

  location = "http://#{IP_ADDR}:#{PORT}/sony/#{service_group}"
  uri = URI.parse(location)
  http = Net::HTTP.new(uri.host, uri.port)
  # http.set_debug_output $stderr

  req = Net::HTTP::Post.new(uri.request_uri)
  req["Content-Type"] = "application/json"
  req.body = request_body.to_json
  res = http.request(req)

  case res
  when Net::HTTPSuccess
    respons_body = JSON.parse(res.body)
  else
    puts "Error!"
    puts "code -> #{res.code}"
    puts [uri.to_s, res.message].join(" : ")
    exit
  end

  print "=== result ===\n"
  print_json(respons_body)
  return respons_body
end

##------------------------------------------------------------------------------------------------
print "test start\n"

service_group = option[:s]
request_file = check_file(option[:f])
respons_file = get_respons_file(request_file)

request_body = load_json(request_file)
respons_body = request(service_group, request_body)

##------------------------------------------------------------------------------------------------
puts respons_body
puts respons_body['result']
# eventInfoArray = respons_body['result']['eventInfo']
##------------------------------------------------------------------------------------------------

write_json(respons_file, respons_body)

print "test end\n"
##------------------------------------------------------------------------------------------------

